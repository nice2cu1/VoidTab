const _="voidtab-core-config",a="voidtab-wallpaper-blob",o="_USE_LOCAL_STORAGE_",s="set-voidtab-wallpaper",t="voidtab_ai_history";export{t as A,_ as C,o as L,a as W,s as a};
